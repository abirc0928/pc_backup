let name = 'Dabur';
if (name.length > 4) {
    name = 'Juvu';
}
console.log(name);
let age = 15;
age = 31;
age = 66;
console.log(age);
const country = 'Bangladesh';
console.log(country);